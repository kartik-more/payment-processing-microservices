package com.cpt.payments.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cpt.payments.entity.TransactionLogEntity;
public interface TransactionLogRepository extends JpaRepository<TransactionLogEntity, Integer>{
		
	}
