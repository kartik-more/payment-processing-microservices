package com.cpt.payments.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cpt.payments.entity.TransactionEntity;

public interface TransactionRepository extends JpaRepository<TransactionEntity,Integer>{
	Optional<TransactionEntity> findByTxnReference(String txnReference);
		
}
