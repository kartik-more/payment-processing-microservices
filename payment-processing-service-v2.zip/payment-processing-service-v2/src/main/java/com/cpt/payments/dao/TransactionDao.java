package com.cpt.payments.dao;

import com.cpt.payments.dto.TransactionDTO;

public interface TransactionDao {

    void save(TransactionDTO transactionDTO);

    TransactionDTO findByTxnReference(String txnReference);

    void updateStatus(String txnReference, String status);

    void saveLog(String txnReference, String fromStatus, String toStatus);
}
