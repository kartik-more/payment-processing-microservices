package com.cpt.payments.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "transactions")
@Data
public class TransactionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "userId")
    private String userId;

    @Column(name = "paymentMethod")
    private String paymentMethod;

    @Column(name = "provider")
    private String provider;

    @Column(name = "paymentType")
    private String paymentType;

    @Column(name = "amount")
    private double amount;

    @Column(name = "currency")
    private String currency;

    @Column(name = "txnStatus")
    private String txnStatus;

    @Column(name = "merchantTxnRef")
    private String merchantTxnRef;

    @Column(name = "txnReference", unique = true)
    private String txnReference;
}