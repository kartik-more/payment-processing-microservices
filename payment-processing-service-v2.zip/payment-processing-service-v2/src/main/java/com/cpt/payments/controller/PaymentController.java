package com.cpt.payments.controller;

import com.cpt.payments.dto.TransactionDTO;
import com.cpt.payments.dto.TransactionResDTO;
import com.cpt.payments.model.PaymentResponse;
import com.cpt.payments.model.Transaction;
import com.cpt.payments.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/payments")
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;
    private final ModelMapper modelMapper;

    public PaymentController(PaymentService paymentService, ModelMapper modelMapper) {
        this.paymentService = paymentService;
        this.modelMapper = modelMapper;
    }

    @PostMapping
    public ResponseEntity<PaymentResponse> createPayment(@RequestBody Transaction transaction) {
        log.info("Create payment request: {}", transaction);

        TransactionDTO transactionDTO = modelMapper.map(transaction, TransactionDTO.class);
        TransactionResDTO resDTO = paymentService.createPayment(transactionDTO);
        PaymentResponse response = modelMapper.map(resDTO, PaymentResponse.class);

        if (response.getErrorCode() != null) {
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PostMapping("/{txnReference}/initiate")
    public ResponseEntity<PaymentResponse> initiatePayment(@PathVariable String txnReference) {
        log.info("Initiate payment: txnReference={}", txnReference);

        TransactionResDTO resDTO = paymentService.initiatePayment(txnReference);
        PaymentResponse response = modelMapper.map(resDTO, PaymentResponse.class);

        if (response.getErrorCode() != null) {
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        return ResponseEntity.ok(response);
    }

    @PostMapping("/{txnReference}/result")
    public ResponseEntity<PaymentResponse> updateStatus(
            @PathVariable String txnReference) {
        log.info("Update status: txnReference={}, newStatus={}", txnReference,"SUCCESS");
        
        TransactionResDTO resDTO = paymentService.updateStatus(txnReference, "SUCCESS");
        PaymentResponse response = modelMapper.map(resDTO, PaymentResponse.class);

        if (response.getErrorCode() != null) {
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        return ResponseEntity.ok(response);
    }
}
