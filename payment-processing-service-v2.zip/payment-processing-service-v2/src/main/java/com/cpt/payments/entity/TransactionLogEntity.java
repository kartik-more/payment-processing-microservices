package com.cpt.payments.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "transaction_log")
@Data
public class TransactionLogEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "txnReference")
    private String txnReference;

    @Column(name = "fromStatus")
    private String fromStatus;

    @Column(name = "toStatus")
    private String toStatus;
}