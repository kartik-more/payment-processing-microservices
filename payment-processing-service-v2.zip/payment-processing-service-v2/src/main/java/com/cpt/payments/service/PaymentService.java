package com.cpt.payments.service;

import com.cpt.payments.dto.TransactionDTO;
import com.cpt.payments.dto.TransactionResDTO;

public interface PaymentService {

    TransactionResDTO createPayment(TransactionDTO transactionDTO);

    TransactionResDTO initiatePayment(String txnReference);

    TransactionResDTO updateStatus(String txnReference, String newStatus);
}
