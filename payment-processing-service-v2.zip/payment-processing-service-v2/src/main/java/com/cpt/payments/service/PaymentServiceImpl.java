package com.cpt.payments.service;

import com.cpt.payments.constant.ErrorCode;
import com.cpt.payments.constant.TransactionStatus;
import com.cpt.payments.dao.TransactionDao;
import com.cpt.payments.dto.TransactionDTO;
import com.cpt.payments.dto.TransactionResDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@Slf4j
public class PaymentServiceImpl implements PaymentService {

    private final TransactionDao transactionDao;

    public PaymentServiceImpl(TransactionDao transactionDao) {
        this.transactionDao = transactionDao;
    }
   
    @Override
    public TransactionResDTO createPayment(TransactionDTO transactionDTO) {
        transactionDTO.setTxnReference(UUID.randomUUID().toString());
        transactionDTO.setTxnStatus(TransactionStatus.CREATED.name());

        transactionDao.save(transactionDTO);
        transactionDao.saveLog(transactionDTO.getTxnReference(), "NEW", TransactionStatus.CREATED.name());

        TransactionResDTO response = new TransactionResDTO();
        response.setTxnReference(transactionDTO.getTxnReference());
        response.setTxnStatus(transactionDTO.getTxnStatus());
        response.setRedirectUrl("http://payment-gateway.com/pay/" + transactionDTO.getTxnReference());

        log.info("Payment created: {}", response);
        return response;
    }

    @Override
    public TransactionResDTO initiatePayment(String txnReference) {
        TransactionDTO transactionDTO = transactionDao.findByTxnReference(txnReference);
        String fromStatus = transactionDTO.getTxnStatus();

        if (fromStatus.equals(TransactionStatus.SUCCESS.name())
                || fromStatus.equals(TransactionStatus.FAILED.name())) {
            log.error("Cannot initiate terminal state transaction. fromStatus={}", fromStatus);
            TransactionResDTO response = new TransactionResDTO();
            response.setErrorCode(ErrorCode.TERMINAL_STATE_ERROR.getCode());
            response.setErrorMessage(ErrorCode.TERMINAL_STATE_ERROR.getMessage());
            return response;
        }

        transactionDao.updateStatus(txnReference, TransactionStatus.INITIATED.name());
        transactionDao.saveLog(txnReference, fromStatus, TransactionStatus.INITIATED.name());

        TransactionResDTO response = new TransactionResDTO();
        response.setTxnReference(txnReference);
        response.setTxnStatus(TransactionStatus.INITIATED.name());
        response.setRedirectUrl("http://payment-gateway.com/pay/" + txnReference);

        log.info("Payment initiated: {}", response);
        return response;
    }

    @Override
    public TransactionResDTO updateStatus(String txnReference, String newStatus) {
        TransactionDTO transactionDTO = transactionDao.findByTxnReference(txnReference);
        String fromStatus = transactionDTO.getTxnStatus();
        if(fromStatus.equals("SUCCESS") || fromStatus.equals("FAILED")){
        		log.error("Cannot initiate terminal state transaction. fromStatus={}", fromStatus);
        		TransactionResDTO response=new TransactionResDTO();
        		response.setErrorCode(ErrorCode.TERMINAL_STATE_ERROR.getCode());
        		response.setErrorMessage(ErrorCode.TERMINAL_STATE_ERROR.getMessage());
        		return response;
        }
        	transactionDao.updateStatus(txnReference, newStatus);
        transactionDao.saveLog(txnReference, fromStatus, newStatus);

        TransactionResDTO response = new TransactionResDTO();
        response.setTxnReference(txnReference);
        response.setTxnStatus(newStatus);

        log.info("Status updated: {}", response);
        return response;
    }
}
