package com.cpt.payments.dao;

import com.cpt.payments.dto.TransactionDTO;
import com.cpt.payments.entity.TransactionEntity;
import com.cpt.payments.entity.TransactionLogEntity;
import com.cpt.payments.repository.TransactionLogRepository;
import com.cpt.payments.repository.TransactionRepository;

import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class TransactionDaoImpl implements TransactionDao {

    private final ModelMapper modelMapper;
    private final TransactionRepository repo;
    private final TransactionLogRepository repoLog;

    public TransactionDaoImpl(ModelMapper modelMapper, TransactionRepository repo,
    		TransactionLogRepository repoLog) {
        this.modelMapper = modelMapper;
		this.repo = repo;
		this.repoLog=repoLog;
    }

    @Override
    public void save(TransactionDTO dto) {
        TransactionEntity entity = modelMapper.map(dto, TransactionEntity.class);
        repo.save(entity);

        log.info("Transaction saved: txnReference={}", entity.getTxnReference());
    }

    @Override
    public TransactionDTO findByTxnReference(String txnReference) {
        TransactionEntity entity=repo.findByTxnReference(txnReference).orElseThrow(() -> 
        			new RuntimeException("Transaction not found for txnReference: " + txnReference));

        return modelMapper.map(entity, TransactionDTO.class);
    }

    @Override
    public void updateStatus(String txnReference, String status) {
        TransactionEntity entity=repo.findByTxnReference(txnReference).orElseThrow(()->
        			new RuntimeException ("Transaction not found for txnReference: " + txnReference));
        entity.setTxnStatus(status);
        repo.save(entity);

        log.info("Status updated to {} for txnReference={}", status, txnReference);
    }

    @Override
    public void saveLog(String txnReference, String fromStatus, String toStatus) {
        TransactionLogEntity entity=new TransactionLogEntity();
        entity.setTxnReference(txnReference);
        entity.setFromStatus(fromStatus);
        entity.setToStatus(toStatus);
        repoLog.save(entity);
        log.info("Log saved: {} -> {} for txnReference={}", fromStatus, toStatus, txnReference);
    }
}
