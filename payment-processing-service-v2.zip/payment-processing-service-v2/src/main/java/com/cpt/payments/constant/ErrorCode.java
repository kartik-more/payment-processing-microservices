package com.cpt.payments.constant;

public enum ErrorCode {

    GENERIC_ERROR("20000", "Unable to process request, please try again later"),
    TERMINAL_STATE_ERROR("20001", "Transaction is already SUCCESS or FAILED and cannot be updated");

    private final String code;
    private final String message;

    ErrorCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() { return code; }
    public String getMessage() { return message; }
}
