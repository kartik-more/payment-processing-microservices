package com.cpt.payments.constant;

public enum TransactionStatus {
    CREATED,
    INITIATED,
    PENDING,
    SUCCESS,
    FAILED
}
