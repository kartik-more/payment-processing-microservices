package com.cpt.payments.service.validator;

import com.cpt.payments.dao.PaymentRequestDao;
import com.cpt.payments.dto.PaymentRequestDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ThresholdValidator implements Validator {

    @Value("${validator.threshold.maxAttempts}")
    private int maxAttempts;

    @Value("${validator.threshold.durationInMins}")
    private int durationInMins;

    private final PaymentRequestDao paymentRequestDao;

    public ThresholdValidator(PaymentRequestDao paymentRequestDao) {
        this.paymentRequestDao = paymentRequestDao;
    }

    @Override
    public boolean validate(PaymentRequestDTO request) {
        int count = paymentRequestDao.countRecentAttempts(request.getUserId(), durationInMins);

        log.info("Payment attempts for userId={}: count={}, max={}", request.getUserId(), count, maxAttempts);

        if (count > maxAttempts) {
            log.error("Threshold exceeded for userId={}", request.getUserId());
            return false;
        }
        return true;
    }
}
