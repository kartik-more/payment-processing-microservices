package com.cpt.payments.dto;

import lombok.Data;

@Data
public class PaymentResponseDTO {
    private String txnReference;
    private String txnStatus;
    private String redirectUrl;
    private String errorCode;
    private String errorMessage;
}
