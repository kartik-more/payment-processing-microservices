package com.cpt.payments.exception;
import com.cpt.payments.constant.ErrorCode;
import com.cpt.payments.dto.PaymentResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
	

    @ExceptionHandler(InvalidAmountException.class)
    public ResponseEntity<PaymentResponseDTO> handleInvalidAmountException(InvalidAmountException ex) {
        log.error("InvalidAmountException caught: {}", ex.getMessage());
        return buildErrorResponse(ErrorCode.INVALID_AMOUNT, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(DuplicatePaymentException.class)
    public ResponseEntity<PaymentResponseDTO> handleDuplicatePaymentException(DuplicatePaymentException ex) {
        log.error("DuplicatePaymentException caught: {}", ex.getMessage());
        return buildErrorResponse(ErrorCode.DUPLICATE_PAYMENT, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(ThresholdExceededException.class)
    public ResponseEntity<PaymentResponseDTO> handleThresholdExceededException(ThresholdExceededException ex) {
        log.error("ThresholdExceededException caught: {}", ex.getMessage());
        return buildErrorResponse(ErrorCode.THRESHOLD_EXCEEDED, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity<PaymentResponseDTO>serviceUnavailable(ServiceUnavailableException su){
    		log.error("Service Unavailable :{}",su.getMessage());
    		return buildErrorResponse(ErrorCode.SERVICE_UNAVAILABLE,HttpStatus.SERVICE_UNAVAILABLE);
    }
    
    private ResponseEntity<PaymentResponseDTO> buildErrorResponse(ErrorCode errorCode, HttpStatus status) {
        PaymentResponseDTO response = new PaymentResponseDTO();
        response.setErrorCode(errorCode.getCode());
        response.setErrorMessage(errorCode.getMessage());
        return new ResponseEntity<>(response, status);
    }
}