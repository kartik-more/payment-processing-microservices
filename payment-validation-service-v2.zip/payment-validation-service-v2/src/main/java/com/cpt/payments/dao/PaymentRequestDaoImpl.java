package com.cpt.payments.dao;

import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Repository;

import com.cpt.payments.entity.MerchantPaymentRequestEntity;
import com.cpt.payments.repository.PaymentRequestRepository;

@Repository
@Slf4j
public class PaymentRequestDaoImpl implements PaymentRequestDao {

    private final PaymentRequestRepository paymentRequestRepository;

    public PaymentRequestDaoImpl(PaymentRequestRepository paymentRequestRepository) {
        this.paymentRequestRepository = paymentRequestRepository;
    }

    @Override
    public boolean save(String merchantTxnRef, String userId) {
        try {
        	MerchantPaymentRequestEntity entity=
        								new MerchantPaymentRequestEntity();
        	entity.setMerchantTxnRef(merchantTxnRef);
        	entity.setUserId(userId);
        	paymentRequestRepository.save(entity);
        	log.info("Payment request saved via JPA: merchantTxnRef={}", merchantTxnRef);
            return true;
        } catch (DuplicateKeyException e) {
            log.error("Duplicate merchantTxnRef={}", merchantTxnRef);
            return false;
        }
    }

    @Override
    public int countRecentAttempts(String userId, int durationInMins) {
    	 LocalDateTime timeLimit = LocalDateTime.now().minusMinutes(durationInMins);
         return paymentRequestRepository.countByUserIdAndCreatedAtAfter(userId, timeLimit);
    }
}
