package com.cpt.payments.service;

import com.cpt.payments.dto.PaymentRequestDTO;
import com.cpt.payments.dto.PaymentResponseDTO;
import com.cpt.payments.exception.DuplicatePaymentException;
import com.cpt.payments.exception.InvalidAmountException;
import com.cpt.payments.exception.ThresholdExceededException;
import com.cpt.payments.http.ProcessingServiceClient;
import com.cpt.payments.service.validator.AmountValidator;
import com.cpt.payments.service.validator.DuplicatePaymentValidator;
import com.cpt.payments.service.validator.ThresholdValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PaymentServiceImpl implements PaymentService {

    private final AmountValidator amountValidator;
    private final DuplicatePaymentValidator duplicatePaymentValidator;
    private final ThresholdValidator thresholdValidator;
    private final ProcessingServiceClient processingServiceClient;

    public PaymentServiceImpl(AmountValidator amountValidator,
                               DuplicatePaymentValidator duplicatePaymentValidator,
                               ThresholdValidator thresholdValidator,
                               ProcessingServiceClient processingServiceClient) {
        this.amountValidator = amountValidator;
        this.duplicatePaymentValidator = duplicatePaymentValidator;
        this.thresholdValidator = thresholdValidator;
        this.processingServiceClient = processingServiceClient;
    }

    @Override
    public PaymentResponseDTO processPayment(PaymentRequestDTO requestDTO) {
        log.info("Starting payment validation for userId={}", requestDTO.getUserId());

        if (!amountValidator.validate(requestDTO)) {
        		System.out.println("exception throw");
            throw new InvalidAmountException("Amount must be greater than zero (0).");
            
        }
        if (!duplicatePaymentValidator.validate(requestDTO)) {
            throw new DuplicatePaymentException("Duplicate payment - this request was already submitted");
        }
        if (!thresholdValidator.validate(requestDTO)) {
            throw new ThresholdExceededException("Too many payment attempts, please try again after some time");
        }

        log.info("All validations passed, calling processing service");
        return processingServiceClient.createPayment(requestDTO);
    }
}
