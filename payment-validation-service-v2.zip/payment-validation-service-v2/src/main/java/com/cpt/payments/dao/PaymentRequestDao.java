package com.cpt.payments.dao;

public interface PaymentRequestDao {

    boolean save(String merchantTxnRef, String userId);

    int countRecentAttempts(String userId, int durationInMins);
}
