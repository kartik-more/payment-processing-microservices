package com.cpt.payments.service.validator;

import com.cpt.payments.dto.PaymentRequestDTO;

public interface Validator {
    boolean validate(PaymentRequestDTO request);
}
