package com.cpt.payments.model;

import lombok.Data;

@Data
public class PaymentResponse {
    private String txnReference;
    private String txnStatus;
    private String redirectUrl;
    private String errorCode;
    private String errorMessage;
}
