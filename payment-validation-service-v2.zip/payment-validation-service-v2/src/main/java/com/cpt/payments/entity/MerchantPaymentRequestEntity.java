package com.cpt.payments.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import lombok.Data;

@Entity
@Table(name="merchant_payment_request")
@Data
public class MerchantPaymentRequestEntity {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
    @Column(name = "merchantTxnRef", unique = true, nullable = false)
    private String merchantTxnRef;
    
    @Column(name = "userId", nullable = false)
    private String userId;
    
    @CreationTimestamp
    @Column(name = "createdAt", updatable = false)
    private LocalDateTime createdAt;


}
