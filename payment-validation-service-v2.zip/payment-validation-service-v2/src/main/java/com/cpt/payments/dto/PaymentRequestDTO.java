package com.cpt.payments.dto;

import lombok.Data;

@Data
public class PaymentRequestDTO {
    private String userId;
    private String paymentMethod;
    private String provider;
    private String paymentType;
    private double amount;
    private String currency;
    private String merchantTxnRef;
}
