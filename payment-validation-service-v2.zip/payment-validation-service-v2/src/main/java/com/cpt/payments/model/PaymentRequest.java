package com.cpt.payments.model;

import lombok.Data;

@Data
public class PaymentRequest {
    private String userId;
    private String paymentMethod;
    private String provider;
    private String paymentType;
    private double amount;
    private String currency;
    private String merchantTxnRef;
}
