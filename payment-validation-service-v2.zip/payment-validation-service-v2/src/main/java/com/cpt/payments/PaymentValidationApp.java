package com.cpt.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentValidationApp {
    public static void main(String[] args) {
        SpringApplication.run(PaymentValidationApp.class, args);
    }
}
