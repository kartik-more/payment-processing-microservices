package com.cpt.payments.constant;

public enum ErrorCode {

    GENERIC_ERROR("10000", "Unable to process request, please try again later"),
    INVALID_AMOUNT("10001", "Amount must be greater than zero (0)."),
    DUPLICATE_PAYMENT("10002", "Duplicate payment - this request was already submitted"),
    THRESHOLD_EXCEEDED("10003", "Too many payment attempts, please try again after some time"),
    SERVICE_UNAVAILABLE("10004", "Processing service is unavailable, please try again later");

    private final String code;
    private final String message;

    ErrorCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() { return code; }
    public String getMessage() { return message; }
}
