package com.cpt.payments.http;

import com.cpt.payments.dto.PaymentRequestDTO;
import com.cpt.payments.dto.PaymentResponseDTO;
import com.cpt.payments.exception.ServiceUnavailableException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class ProcessingServiceClient {

    private final RestTemplate restTemplate;

    @Value("${processing.service.url}")
    private String processingServiceUrl;

    public ProcessingServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public PaymentResponseDTO createPayment(PaymentRequestDTO requestDTO) {
        try {
            log.info("Calling processing service: url={}", processingServiceUrl);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<PaymentRequestDTO> httpEntity = new HttpEntity<>(requestDTO, headers);

            ResponseEntity<PaymentResponseDTO> response = restTemplate.exchange(
                    processingServiceUrl, HttpMethod.POST, httpEntity, PaymentResponseDTO.class);

            log.info("Processing service response: {}", response.getBody());

            return response.getBody();

        } catch (Exception e) {
            log.error("Processing service call failed: {}", e.getMessage());
            
            throw new ServiceUnavailableException("Processing service is unavailable, please try again later");
        }
    }
}
