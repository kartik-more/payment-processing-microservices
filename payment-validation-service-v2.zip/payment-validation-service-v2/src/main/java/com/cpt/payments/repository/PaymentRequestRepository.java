package com.cpt.payments.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cpt.payments.entity.MerchantPaymentRequestEntity;

@Repository
public interface PaymentRequestRepository extends
				JpaRepository<MerchantPaymentRequestEntity,Integer>{
	int countByUserIdAndCreatedAtAfter(String userId, LocalDateTime dateTime);
}
