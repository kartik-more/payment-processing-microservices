package com.cpt.payments.controller;

import com.cpt.payments.dto.PaymentRequestDTO;
import com.cpt.payments.dto.PaymentResponseDTO;
import com.cpt.payments.model.PaymentRequest;
import com.cpt.payments.model.PaymentResponse;
import com.cpt.payments.service.PaymentService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/payments")
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;
    private final ModelMapper modelMapper;

    public PaymentController(PaymentService paymentService, ModelMapper modelMapper) {
        this.paymentService = paymentService;
        this.modelMapper = modelMapper;
    }

    @PostMapping
    public ResponseEntity<PaymentResponse> validateAndCreatePayment(@Valid @RequestBody PaymentRequest request) {
        log.info("Received payment request: userId={}, amount={}", request.getUserId(), request.getAmount());

        PaymentRequestDTO requestDTO = modelMapper.map(request, PaymentRequestDTO.class);
        PaymentResponseDTO responseDTO = paymentService.processPayment(requestDTO);
        PaymentResponse response = modelMapper.map(responseDTO, PaymentResponse.class);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

}
