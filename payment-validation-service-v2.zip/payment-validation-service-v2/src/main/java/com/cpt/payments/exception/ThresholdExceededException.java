package com.cpt.payments.exception;

public class ThresholdExceededException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ThresholdExceededException(String message) {
        super(message);
    }
}