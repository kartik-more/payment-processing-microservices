package com.cpt.payments.service.validator;

import com.cpt.payments.dto.PaymentRequestDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class AmountValidator implements Validator {

    @Override
    public boolean validate(PaymentRequestDTO request) {
        if (request.getAmount() <= 0) {
            log.error("Invalid amount: {}", request.getAmount());
            return false;
        }
        return true;
    }
}
