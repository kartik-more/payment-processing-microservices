package com.cpt.payments.service.validator;

import com.cpt.payments.dao.PaymentRequestDao;
import com.cpt.payments.dto.PaymentRequestDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DuplicatePaymentValidator implements Validator {

    private final PaymentRequestDao paymentRequestDao;

    public DuplicatePaymentValidator(PaymentRequestDao paymentRequestDao) {
        this.paymentRequestDao = paymentRequestDao;
    }

    @Override
    public boolean validate(PaymentRequestDTO request) {
        boolean saved = paymentRequestDao.save(request.getMerchantTxnRef(), request.getUserId());
        if (!saved) {
            log.error("Duplicate payment detected: merchantTxnRef={}", request.getMerchantTxnRef());
        }
        return saved;
    }
}
